INSERT INTO chats (chat_id, type, title, username)
VALUES (?, ?, ?, ?)