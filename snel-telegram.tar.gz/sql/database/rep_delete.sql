DELETE FROM repeaters
WHERE rowid = ?