INSERT INTO users (user_id, first_name, last_name, username, language)
VALUES (?, ?, ?, ?, ?)