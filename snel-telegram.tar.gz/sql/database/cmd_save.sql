INSERT INTO cmd_data (user_id, chat_id, command)
VALUES (?, ?, ?)