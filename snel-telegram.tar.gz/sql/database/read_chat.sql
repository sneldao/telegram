SELECT *
FROM chats
WHERE chat_id = ?