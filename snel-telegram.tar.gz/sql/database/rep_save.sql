INSERT INTO repeaters (user_id, chat_id, command, interval, updt)
VALUES (?, ?, ?, ?, ?)