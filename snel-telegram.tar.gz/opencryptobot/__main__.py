from opencryptobot.start import OpenCryptoBot

OpenCryptoBot().start()
