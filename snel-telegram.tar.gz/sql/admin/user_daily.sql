SELECT date_time, first_name
FROM users
ORDER BY 1 DESC
LIMIT 40